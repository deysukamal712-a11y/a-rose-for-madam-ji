FOREVER, MADAM JI — FREE WEBSITE FILES

Included:
- index.html: the interactive mobile-first 3D rose experience (red rose transforms into a lavender rose)
- gaan.mp3: your supplied background music

Preview locally:
1. Keep index.html and gaan.mp3 in the same folder.
2. Open index.html in a modern browser. (The 3D library loads from a CDN, so internet is needed.)

Publish free with GitHub Pages:
1. Create/sign in to a free GitHub account.
2. Create a new PUBLIC repository, for example: forever-madam-ji
3. Upload index.html and gaan.mp3 to the repository root.
4. Open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch; select main and /(root), then Save.
6. Wait for GitHub Pages to publish. The public link will appear in the Pages settings and anyone with it can visit without signing in.

No paid plan or payment card is needed for GitHub Pages on a public repository.
